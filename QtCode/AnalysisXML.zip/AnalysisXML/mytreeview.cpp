#include "mytreeview.h"
#include <QKeyEvent>
#include <QDebug>

MyTreeView::MyTreeView() {

}

MyTreeView::MyTreeView(QWidget *parent):QTreeView(parent) {

}

